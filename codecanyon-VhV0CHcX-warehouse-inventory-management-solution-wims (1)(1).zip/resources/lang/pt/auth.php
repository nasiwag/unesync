<?php

return [
    'failed'   => 'As credenciais indicadas não coincidem com as registadas no sistema.',
    'password' => 'A palavra-passe indicada está incorreta.',
    'throttle' => 'O número limite de tentativas de login foi atingido. Por favor tente novamente dentro de :seconds segundos.',
];
