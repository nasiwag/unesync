<!DOCTYPE html>
<html lang="en" class="h-full bg-gray-900">
  <head>
    <meta charset="UTF-8" />
    <link rel="icon" type="image/png" href="/vendor/installer/icon.png" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Tecdiary Installer</title>
    <script type="module" crossorigin src="/vendor/installer/assets/index.732b71ad.js"></script>
    <link rel="stylesheet" href="/vendor/installer/assets/index.49cb7bd2.css">
  </head>
  <body class="h-full">
    <div id="app" class="min-h-full bg-white"></div>
    
  </body>
</html>
